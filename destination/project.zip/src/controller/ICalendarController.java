package controller;

import model.ICalendarModel;
import view.IView;

/**
 * Represents a controller interface for the Calendar application.
 * <p>
 * An implementing class of this interface coordinates the communication between
 * the calendar model (containing event data) and a view (for input/output).
 * It handles user commands and invokes the appropriate model methods to perform
 * actions such as adding events, editing events, printing, exporting, and more.
 * </p>
 */

public interface ICalendarController {
  static ICalendarController createInstance(String version, ICalendarModel model,
                                            IView view) {
    if (version.equalsIgnoreCase("basic")) {
      return new CalendarControllerBasic(model, view);
    } else if (version.equalsIgnoreCase("advanced")) {
      return new CalendarController(model, view);
    } else {
      throw new IllegalArgumentException("Unsupported version: " + version);
    }
  }

  void run(Readable readable);
}
